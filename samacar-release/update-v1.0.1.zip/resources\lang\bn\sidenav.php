<?php

return [
    'title' => 'সমাচার',
    'dashboard' => 'ড্যাশবোর্ড',
    'customer' => 'কাস্টমার',
    'product' => 'প্রোডাক্ট',
    'invoice' => 'ইনভয়েস',
    'reports' => 'রিপোর্ট',
    'settings' => 'সেটিংস',
    'accounts' => 'একাউন্টস্',
    'expenses' => 'ব্যয় সমূহ',
    'income' => 'আয় সমূহ',
    'profile' => 'প্রোফাইল',
    'logout' => 'লগ আউট',
    'balance_sheet' => 'ব্যালেন্স শিট',
    'newspaper' => 'নিউজপেপার',
    'management' => 'ম্যানেজমেন্ট',
    'users' => 'ইউজার',
    'samacar' => 'সমাচার'
];
