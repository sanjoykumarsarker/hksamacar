<li class="nav-item dropdown no-arrow mx-1">
    <a
        class="nav-link dropdown-toggle"
        href="#"
        id="messagesDropdown"
        role="button"
        data-toggle="dropdown"
        aria-haspopup="true"
        aria-expanded="false"
    >
        <i class="fas fa-bell fa-fw"></i>
        @if(auth()->user()->unreadNotifications->count())
        <span
            class="badge badge-danger badge-counter"
            >{{auth()->user()->unreadNotifications->count()}}</span
        >
        @endif
    </a>
    <!-- Dropdown - Messages -->
    <div
        class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
        aria-labelledby="messagesDropdown"
    >
        <h6 class="dropdown-header">
            Notifications
        </h6>
        @forelse(auth()->user()->unreadNotifications as $notification)
        <a class="dropdown-item" href="{{$notification->data['link']}}">
            <div class="font-weight-bold">
                <div class="text-truncate">
                    {{$notification->data['message']}}
                </div>
                <div class="small text-gray-500">
                    {{$notification->created_at}}
                </div>
            </div>
        </a>
        @empty
        <a class="dropdown-item d-flex align-items-center" href="#">
            <div>
                <div class="text-truncate">
                    No New Notifications
                </div>
            </div>
        </a>
        @endforelse

        <!-- <a class="dropdown-item d-flex align-items-center" href="#">
            <div class="dropdown-list-image mr-3">
                <img
                    class="rounded-circle"
                    src="https://source.unsplash.com/Mv9hjnEUHR4/60x60"
                    alt=""
                />
                <div class="status-indicator bg-success"></div>
            </div>
            <div>
                <div class="text-truncate">
                    Am I a good boy? The reason I ask is because someone told me
                    that people say this to all dogs, even if they aren't
                    good...
                </div>
                <div class="small text-gray-500">
                    Chicken the Dog · 2w
                </div>
            </div>
        </a> -->
        <a class="dropdown-item text-center small text-gray-500" href="#"
            >Read More Messages</a
        >
    </div>
</li>
