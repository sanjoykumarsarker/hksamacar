<nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
    <!-- Sidebar Toggle (Topbar) -->
    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
        <i class="fa fa-bars"></i>
    </button>

    <header-search ></header-search>
    <!-- Topbar Navbar -->
    <ul class="navbar-nav ml-auto">
        <li class="nav-item">
            <a href="{{ route('lang') }}" class="nav-link">
                <button class="btn btn-sm btn-outline-danger">
                    {{strtoupper(app()->getLocale())}}
                </button>
            </a>
        </li>
        <li class="nav-item">
            <a href="{{ route('invoice.create') }}" class="nav-link">
                <img src="{{ asset('img/index.png') }}" alt="invoice" class="img-fluid" style="margin-top:-15px;" width="50" />
            </a>
        </li>
        <!-- Nav Item - Alerts -->
        <li class="nav-item">
            <a href="#" @click.prevent="dbSync" class="nav-link" title="Sync Database" data-toggle="tooltip" data-placement="bottom">
                <i class="fas fa-sync" aria-hidden="true"></i>
            </a>
        </li>

        <!-- Nav Item - Messages -->
        @auth
        @include('layouts.notification')
        @endauth

        <div class="topbar-divider d-none d-sm-block"></div>
        <!-- <li class="nav-item">
            <a class="nav-link text-dark" href="#" data-toggle="modal" data-target="#logoutModal" >
                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2"></i>
                    Logout
                </a>
        </li> -->

        <!-- Nav Item - User Information -->
        <li class="nav-item dropdown no-arrow">
            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <span class="mr-2 d-none d-md-inline text-dark small text-truncate">{{auth()->user()->name}}</span>
                <span class="mr-2 d-block d-md-none text-dark small"><i class="fa fa-user"></i></span>
            </a>
            <!-- Dropdown - User Information -->
            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                <a class="dropdown-item {{ Route::is('user.show') ? 'active' : '' }}" href="{{route('user.show', auth()->id())}}">
                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                    {{ __("sidenav.profile") }}
                </a>
                <a class="dropdown-item {{ Route::is('settings') ? 'active' : '' }}" href="{{ route('settings') }}">
                    <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                    {{ __("sidenav.settings") }}
                </a>
                <!-- <a class="dropdown-item" href="#">
                <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                Activity Log
            </a> -->
                <div class="dropdown-divider"></div>
                @impersonating
                <a href="{{ route('impersonate.leave') }}" class="dropdown-item">
                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                    {{ __("Leave impersonation") }}</a>
                @else
                <a class="dropdown-item" href="{{ route('logout') }}" onclick="event.preventDefault();
                          document.getElementById('logout-form').submit();">
                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                    {{ __("sidenav.logout") }}
                </a>
                <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                    @csrf
                </form>
                @endImpersonating
            </div>
        </li>
    </ul>
</nav>