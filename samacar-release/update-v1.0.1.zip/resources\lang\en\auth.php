<?php

return [
    'welcome' => 'Welcome Back!',
    'remember' => 'Remember Me',
    'login' => 'Login',
    'forget_password' => 'Forgot Password?',
    'create_account' => 'Create an Account!',
    'password' => 'Password',
    'email_placeholder' => 'Enter Email Address...',
    'failed' => 'These credentials do not match our records.',
    'throttle' => 'Too many login attempts. Please try again in :seconds seconds.',

];
