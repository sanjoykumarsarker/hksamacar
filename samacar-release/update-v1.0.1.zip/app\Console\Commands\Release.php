<?php

namespace App\Console\Commands;

use Illuminate\Http\File;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Storage;
use Symfony\Component\Console\Helper\ProgressBar;

class Release extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'release:out {--new : Make New Release} {--dry : Runs in dry mode without executing.} {--force : No Question.}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Make New Release using chhanged file directly in server using sftp.';

    protected $destination = "E:\samacar_release\hksamacar";
    protected $version_file = 'version.txt';
    protected $changed_file = 'changed.txt';
    protected $current_version = null;
    protected $newer_version = null;

    protected $files = [
        '.env',
        'artisan',
        'server.php',
        'version.txt',
        'app/*',
        'config/*',
        'database/*',
        'public/*',
        'routes/*',
        'bootstrap/app.php',
        'storage/*',
        'resources/*',
        'bootstrap/cache',
    ];

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
        $this->get_current_version();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $isDry = $this->option('dry');
        // $name = $this->ask('What is your name?');
        shell_exec('git diff HEAD~1 --name-only > ' . base_path($this->changed_file));
        // echo file_get_contents(base_path('ups.txt'));
        $this->make_version_decision();
        //     $this->line('');
        // $this->error('Something went wrong!');
    }


    protected function upload($filename, $version, $des)
    {
        $description = $this->ask("Add Release Description.", $des);
        $data = [
            "version" => $version,
            "date" => date('D d-M-Y h:i A'),
            "archive" => $filename,
            "description" => $description
        ];
        ProgressBar::setFormatDefinition('custom', ' %current%/%max% [%bar%] %message%');
        $bar = $this->output->createProgressBar(5);
        $bar->setFormat('custom');
        $bar->setMessage("Setting update in laraupdater.json...");
        $bar->start();
        $bar->advance();
        $resource = fopen(base_path($filename), 'r+');
        $bar->advance();
        $isDry = $this->option('dry');
        if (!$isDry) {
            Storage::disk('release')->put('laraupdater.json', json_encode($data));
        }
        $bar->advance();
        $bar->setMessage("Uploading to server...");
        if (!$isDry) {
            Storage::disk('release')->put($filename, $resource);
        }
        $bar->advance();
        // Storage::disk('release')->putFileAs(new File(base_path($filename), $filename));
        fclose($resource);
        $bar->advance();
        $bar->setMessage("Upload Completed");
        $bar->finish();
        $this->info("\nNew Release with Version: " . $version . " successfully uploaded to server");
    }

    // protected function upload_progress($notificationCode, $severity, $message, $messageCode, $bytesTransferred, $bytesMax)
    // {
    //     // var_dump($notificationCode, $severity, $message, $messageCode, $bytesTransferred, $bytesMax);
    //     // https://hannesvdvreken.com/2015/05/12/stream-progress/
    //     $upload_progress_bar = null;
    //     // $this->upload_progress_bar->start();
    //     if (STREAM_NOTIFY_REDIRECTED === $notificationCode) {
    //         // $upload_progress_bar->clear();
    //         $upload_progress_bar = null;
    //         return;
    //     }

    //     if (STREAM_NOTIFY_FILE_SIZE_IS === $notificationCode) {
    //         if ($upload_progress_bar) {
    //             $upload_progress_bar->clear();
    //         }
    //         $filesize = $bytesMax;
    //         $upload_progress_bar = $this->output->createProgressBar($bytesMax);
    //     }

    //     if (STREAM_NOTIFY_PROGRESS === $notificationCode) {
    //         if (is_null($upload_progress_bar)) {
    //             $upload_progress_bar = $this->output->createProgressBar();
    //         }
    //         $upload_progress_bar->setProgress($bytesTransferred);
    //     }

    //     if (STREAM_NOTIFY_COMPLETED === $notificationCode) {
    //         $upload_progress_bar->finish();
    //     }
    // }


    protected function make_version_decision()
    {
        $exists = file_exists(base_path("update-v" . $this->current_version . ".zip"));
        $decision = false;
        if ($exists) {
            $decision = $this->confirm('Do you like to merge with existing version?');
        }
        if ($decision) {
            $this->create_zip($this->current_version);
        } else {
            $this->create_zip($this->newer_version);
            $this->update_version();
        }
    }

    protected function create_zip($version)
    {
        $zip = new \ZipArchive();

        $file_path = "update-v" . $version . ".zip";

        if (file_exists(base_path($file_path))) {
            unlink(base_path($file_path));
        }

        $file =  file(base_path($this->changed_file));
        $files_count = count($file);

        if ($files_count > 0) {
            $zip->open(base_path($file_path), \ZipArchive::CREATE | \ZipArchive::OVERWRITE);

            $bar = $this->output->createProgressBar($files_count);
            $bar->start();

            foreach ($file as $line) {
                $line = str_replace('/', '\\', trim($line));
                if (file_exists(base_path($line))) {
                    $isDry = $this->option('dry');
                    if (!$isDry) {
                        $zip->addFile(base_path($line), $line);
                    }
                }
                $bar->advance();
            }

            $zip->close();
            $bar->finish();
            $this->line('');
            $this->info("Successfully Zipped " . $files_count . " files");
            $this->info("New Version is " . $version);
            $this->upload($file_path, $version, "New update in " . $files_count . " files");
        } else {
            $this->line('');
            $this->error('There is no changed file.');
        }
    }

    protected function update_version()
    {
        file_put_contents($this->version_file, $this->newer_version);
    }

    protected function get_current_version()
    {
        $v = file_get_contents(base_path($this->version_file));
        $this->current_version = $v;
        $this->newer_version = $this->increment_version($v);
    }

    protected function get_location(): String
    {
        $isNew = $this->option('new');
        $version = $isNew ? $this->increment_version($this->current_version) : $this->current_version;
        return $this->destination . '\\v' . $version;
    }
    // git diff HEAD~1 --name-only > up.txt

    protected function increment_version($version): String
    {
        $parts = explode('.', $version);

        if ($parts[2] + 1 < 9) {
            $parts[2]++;
        } else {
            $parts[2] = 0;
            if ($parts[1] + 1 < 9) {
                $parts[1]++;
            } else {
                $parts[1] = 0;
                $parts[0]++;
            }
        }

        return implode('.', $parts);
    }
}
