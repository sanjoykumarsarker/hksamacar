<?php

return [

    'welcome' => 'স্বাগতম',
    'remember' => 'মনে রাখুন',
    'login' => 'লগ ইন',
    'forget_password' => 'পাসওয়ার্ড ভুলে গেছেন?',
    'create_account' => 'নতুন একাউন্ট করুন!',
    'password' => 'পাসওয়ার্ড',
    'email_placeholder' => 'ইমেল লিখুন',
    'failed' => 'These credentials do not match our records.',
    'throttle' => 'Too many login attempts. Please try again in :seconds seconds.',

];
