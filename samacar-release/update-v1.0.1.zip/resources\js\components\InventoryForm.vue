<template>
  <div>
    <form v-if="!submitted">
      <div class="form-group d-flex justify-content-between">
        <h5 class="text-primary">{{selectedProduct.name}}</h5>
        <h5 class="text-success">Total: {{totalSum}}</h5>
      </div>
      <div class="form-group row">
        <div class="col-6">
          <div class="input-group">
            <div class="input-group-prepend">
              <label for="date" class="input-group-text">Date</label>
            </div>
            <input type="date" name="date" class="form-control" v-model="date" />
          </div>
        </div>
        <div class="col-6">
          <div class="input-group">
            <div class="input-group-prepend">
              <label for="amount" class="input-group-text">Amount</label>
            </div>
            <input type="number" name="amount" class="form-control" v-model.number="amount" />
          </div>
        </div>
        <div class="col-6 mt-3">
          <div class="input-group">
            <div class="input-group-prepend">
              <label for="amount" class="input-group-text">Expense</label>
            </div>
            <input type="number" name="expense" class="form-control" v-model.number="expense" />
          </div>
        </div>
      </div>
      <div class="form-group">
        <button class="btn btn-success btn-block" @click.prevent="submitForm">Submit</button>
      </div>
    </form>
    <div class="text-center" v-else>
      <h4 class="text-danger">Inventory Added</h4>
    </div>
  </div>
</template>

<script>
export default {
  props: ["selectedProduct"],
  data() {
    return {
      id: 0,
      amount: "",
      expense: 0,
      date: new Date().toISOString().slice(0, 10),
      submitted: false
    };
  },
  methods: {
    submitForm: function() {
      axios
        .post(`/product/inventory/${this.selectedProduct.id}`, {
          product_id: this.selectedProduct.id,
          amount: this.amount,
          expense: this.expense
        })
        .then(res => {
          this.amount = "";
          this.submitted = true;
          this.$emit("newInventory", res.data);
        });
    }
  },
  computed: {
    totalSum() {
      return parseInt(this.selectedProduct.stock) + (this.amount || 0);
    }
  }
};
</script>