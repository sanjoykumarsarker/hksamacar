@extends('layouts.app') @section('content')
<div class="container">
  <div class="row justify-content-center">
    <div class="col-xl-10 col-lg-12 col-md-9">
      <div class="card o-hidden border-0 shadow-lg my-5">
        <div class="card-body p-0">
          <!-- Nested Row within Card Body -->
          <div class="row">
            <div class="col-lg-6 d-none d-lg-block bg-login-image"></div>
            <div class="col-lg-6">
              <div class="p-5">
                <div class="text-center">
                  <h1 class="h4 text-gray-900 mb-4">
                    {{ __("auth.welcome") }}
                  </h1>
                  @if (session('message'))
                  <div class="text-danger mb-2">
                    {{ session("message") }}
                  </div>
                  @endif
                </div>
                <form class="user" method="POST" action="{{ route('login') }}">
                  @csrf
                  <div class="form-group">
                    <input type="email" class="form-control form-control-user @error('email') is-invalid @enderror" id="exampleInputEmail" aria-describedby="emailHelp" placeholder="{{__('auth.email_placeholder')}}" required autocomplete="email" autofocus name="email" />
                    @error('email')
                    <span class="invalid-feedback" role="alert">
                      <strong>{{ $message }}</strong>
                    </span>
                    @enderror
                  </div>
                  <div class="form-group">
                    <input type="password" class="form-control form-control-user  @error('password') is-invalid @enderror" id="exampleInputPassword" placeholder="{{__('password')}}" name="password" required autocomplete="current-password" />
                    @error('password')
                    <span class="invalid-feedback" role="alert">
                      <strong>{{ $message }}</strong>
                    </span>
                    @enderror
                  </div>
                  <div class="form-group">
                    <div class="custom-control custom-checkbox small">
                      <input type="checkbox" class="custom-control-input" name="remember" id="remember" {{old("remember") ? "checked": ""}}>
                      <label class="custom-control-label" for="remember">
                        {{ __("auth.remember") }}
                      </label>
                    </div>
                  </div>
                  <button class="btn btn-primary btn-user btn-block" type="submit">
                    {{ __("auth.login") }}
                  </button>
                </form>
                <hr />
                <div class="d-flex justify-content-between">
                  <a class="small" href="{{ route('password.request') }}">{{ __("auth.forget_password") }}</a>
                  <a class="small" href="{{ route('register') }}">{{ __("auth.create_account") }}</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
@endsection