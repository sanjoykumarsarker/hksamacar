<?php

namespace App;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Facades\Cache;
use Lab404\Impersonate\Models\Impersonate;

class User extends Authenticatable
{
    use Notifiable, Impersonate, Syncable;


    protected $fillable = [
        'name', 'email', 'password', 'role', 'banned_until'
    ];

    protected $dates = [
        'banned_until'
    ];


    protected $hidden = [
        'password', 'remember_token',
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function product()
    {
        return $this->hasMany('App\Product');
    }

    public function activities()
    {
        return $this->hasMany('App\Activity');
    }

    public function invoice()
    {
        return $this->hasMany('App\Invoice');
    }

    public function isOnline()
    {
        return Cache::has('is-online-' . $this->id);
    }

    public function canImpersonate()
    {
        return $this->role == 'super-admin';
    }

    public function canBeImpersonated()
    {
        if ($this->role !== 'super-admin') {
            if ($this->checkActiveStatus()) {
                return true;
            }
        }
        return false;
    }

    public function checkActiveStatus()
    {
        if ($this->banned_until && now()->lessThan($this->banned_until))  return false;
        return true;
    }

    public function getIsActiveAttribute()
    {
        return $this->checkActiveStatus();
    }
}
