<ul
    class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion"
    id="accordionSidebar"
>
    <!-- Sidebar - Brand -->
    <a
        class="sidebar-brand d-flex align-items-center justify-content-center"
        href="/home"
    >
        <div class="sidebar-brand-icon">
            <i class="fas fa-desktop"></i>
        </div>
        <div class="sidebar-brand-text mx-3">{{ __("sidenav.title") }}</div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0" />

    <!-- Nav Item - Dashboard -->
    <li class="nav-item {{ Route::is('home') ? 'active' : '' }}">
        <a class="nav-link" href="/home">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>{{ __("sidenav.dashboard") }}</span>
        </a>
    </li>

    <!-- Divider -->
    <!-- <hr class="sidebar-divider" /> -->

    <li class="nav-item {{ Route::is('customer.index') ? 'active' : '' }}">
        <a class="nav-link" href="{{ route('customer.index') }}">
            <i class="fas fa-fw fa-user-alt"></i>
            <span>{{ __("sidenav.customer") }}</span>
        </a>
    </li>
    <li class="nav-item {{ Route::is('product.index') ? 'active' : '' }}">
        <a class="nav-link" href="{{ route('product.index') }}">
            <i class="fas fa-fw fa-receipt"></i>
            <span>{{ __("sidenav.product") }}</span>
        </a>
    </li>
    <li class="nav-item {{ Route::is('newspaper.index') ? 'active' : '' }}">
        <a class="nav-link" href="{{ route('newspaper.index') }}">
            <i class="fas fa-fw fa-receipt"></i>
            <span>{{ __("sidenav.newspaper") }}</span>
        </a>
    </li>

    <li class="nav-item {{ Route::is('invoice.*') ? 'active' : '' }}">
        <a
            class="nav-link collapsed"
            href="#"
            data-toggle="collapse"
            data-target="#collapseUtilities"
            aria-expanded="true"
            aria-controls="collapseUtilities"
        >
            <i class="fas fa-fw fa-book"></i>
            <span>{{ __("sidenav.invoice") }}</span>
        </a>
        <div
            id="collapseUtilities"
            class="collapse"
            aria-labelledby="headingUtilities"
            data-parent="#accordionSidebar"
        >
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="{{ route('invoice.create') }}"
                    >Create New</a
                >
                <a class="collapse-item" href="{{ route('invoice.index') }}"
                    >All Invoice</a
                >
            </div>
        </div>
    </li>
    <hr class="sidebar-divider" />

    <!-- Heading -->
    <div class="sidebar-heading">
        {{ __("sidenav.samacar") }}
    </div>

    <!-- Nav Item - Pages Collapse Menu -->
    <li class="nav-item">
        <a
            class="nav-link collapsed"
            href="#"
            data-toggle="collapse"
            data-target="#collapsePages"
            aria-expanded="true"
            aria-controls="collapsePages"
        >
            <i class="fas fa-fw fa-folder"></i>
            <span>{{ __("sidenav.customer") }}</span>
        </a>
        <div
            id="collapsePages"
            class="collapse"
            aria-labelledby="headingPages"
            data-parent="#accordionSidebar"
        >
            <div class="bg-white py-2 collapse-inner rounded">
                <!-- <h6 class="collapse-header">Login Screens:</h6> -->
                <a
                    class="collapse-item"
                    href="{{ route('samacar.subscribers') }}"
                    >{{ __("sidenav.members") }}</a
                >
                <!-- <div class="collapse-divider"></div>
            <h6 class="collapse-header">Other Pages:</h6>
            <a class="collapse-item" href="/404">404 Page</a>
            <a class="collapse-item" href="/blank">Blank Page</a> -->
            </div>
        </div>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider" />

    <li class="nav-item {{ Route::is('account.*') ? 'active' : '' }}">
        <a
            class="nav-link collapsed"
            href="#"
            data-toggle="collapse"
            data-target="#collapseTwo"
            aria-expanded="true"
            aria-controls="collapseTwo"
        >
            <i class="fas fa-fw fa-funnel-dollar"></i>
            <span>{{ __("sidenav.accounts") }}</span>
        </a>
        <div
            id="collapseTwo"
            class="collapse"
            aria-labelledby="headingTwo"
            data-parent="#accordionSidebar"
        >
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="{{ route('expense.index') }}">
                    {{ __("sidenav.expenses") }}
                </a>
                <a class="collapse-item" href="{{ route('account.index') }}">
                    {{ __("sidenav.income") }}
                </a>
                <!-- <a class="collapse-item" href="#">{{
                    __("sidenav.balance_sheet")
                }}</a> -->
                <a class="collapse-item" href="{{ route('report.index') }}">
                    <span>{{ __("sidenav.reports") }}</span>
                </a>
            </div>
        </div>
    </li>

    <!-- <li class="nav-item {{ Route::is('report.index') ? 'active' : '' }}">
        <a class="nav-link" href="{{ route('report.index') }}">
            <i class="fas fa-fw fa-file"></i>
            <span>{{ __("sidenav.reports") }}</span>
        </a>
    </li> -->
    <!-- <li class="nav-item {{ Route::is('user.index') ? 'active' : '' }}">
        <a class="nav-link" href="{{ route('user.index') }}">
            <i class="fas fa-fw fa-user"></i>
            <span>{{ __("sidenav.users") }}</span>
        </a>
    </li>
    <li class="nav-item {{ Route::is('settings') ? 'active' : '' }}">
        <a class="nav-link" href="{{ route('settings') }}">
            <i class="fas fa-fw fa-cog"></i>
            <span>{{ __("sidenav.settings") }}</span>
        </a>
    </li> -->
    <li class="nav-item">
        <a
            class="nav-link collapsed"
            href="#"
            data-toggle="collapse"
            data-target="#collapseThree"
            aria-expanded="true"
            aria-controls="collapseThree"
        >
            <i class="fas fa-fw fa-cogs"></i>
            <span>{{ __("sidenav.management") }}</span>
        </a>
        <div
            id="collapseThree"
            class="collapse"
            aria-labelledby="headingThree"
            data-parent="#accordionSidebar"
        >
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="{{ route('user.index') }}">
                    <i class="fas fa-fw fa-user-cog"></i>
                    <span>{{ __("sidenav.users") }}</span>
                </a>
                <a class="collapse-item" href="{{ route('settings') }}">
                    <i class="fas fa-fw fa-cog"></i>
                    <span>{{ __("sidenav.settings") }}</span>
                </a>
            </div>
        </div>
    </li>
    <!-- <li class="nav-item">
        <a
            class="nav-link collapsed"
            href="#"
            data-toggle="collapse"
            data-target="#report"
            aria-expanded="true"
            aria-controls="report"
        >
            <i class="fas fa-fw fa-file"></i>
            <span>Reports</span>
        </a>
        <div
            id="report"
            class="collapse"
            aria-labelledby="report"
            data-parent="#accordionSidebar"
        >
            <div class="bg-white py-2 collapse-inner rounded">
                <a class="collapse-item" href="route('report.index')">Report</a>
                <a class="collapse-item" href="{{ route('report.sales') }}"
                    >Sales Report</a
                >
            </div>
        </div>
    </li> -->

    <!-- Divider -->
    <hr class="sidebar-divider d-none d-md-block" />

    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>
</ul>
