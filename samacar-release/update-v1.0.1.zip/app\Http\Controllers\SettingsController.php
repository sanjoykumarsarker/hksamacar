<?php

namespace App\Http\Controllers;

use App\Sync;
use App\Settings;
use App\Custom\Setting;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class SettingsController extends Controller
{
  public function __construct()
  {
    $this->middleware('auth', ['only' => 'index']);
  }
  public function index(Setting $setting)
  {
    $settings = Settings::first();
    if (request()->ajax() || request()->wantsJson()) {
      return response()->json($setting->all(), Response::HTTP_OK);
    } else {
      return view('settings', compact('settings', 'setting'));
    }
  }

  public function store(Request $request, Setting $setting)
  {
    $request->validate(['key' => 'required', 'value' => 'required']);

    $d = ["True", "true", "False", "false", "TRUE", "FALSE"];

    $value = $request->get('value');

    if (in_array($value, $d)) {
      $value = filter_var($value, FILTER_VALIDATE_BOOLEAN);
    } elseif (strpos($value, ',') !== false) {
      $value = explode(',', $value);
    }

    $setting->put([$request->get('key') => $value]);

    return response()->json($setting->all(), Response::HTTP_CREATED);
  }

  public function checkForUpdate()
  {
    if (!$this->is_connected()) {
      $msg = "Connection Failed. Try Later";
      $status = 'error';
      return response()->json(['message' => $msg, 'ready' => false, 'status' => $status], Response::HTTP_OK);
    }

    $update = app('pcinaglia\laraupdater\LaraUpdaterController')->check();
    $version = app('pcinaglia\laraupdater\LaraUpdaterController')->getCurrentVersion();

    $msg = $update ? "New Update Available: " . $update : "Already Updated to Latest Version: " . $version;
    $ready = $update ? true : false;
    $status = 'info';
    return response()->json(['message' => $msg, 'ready' => $ready, 'status' => $status], Response::HTTP_OK);
  }

  public function downloadUpdate()
  {
    $content = app('pcinaglia\laraupdater\LaraUpdaterController')->update();
    return response()->json($content, Response::HTTP_OK);
  }

  public function editExpenseType(Request $request)
  {
    $set = Settings::first();
    $data = $request->input('expTypes');
    $set->expense_type = json_decode($data, true);
    $set->save();
    return response()->json(['message' => 'Successfully updated'], Response::HTTP_OK);
  }

  public function update(Request $request, Setting $setting)
  {
    $setting->put($request->all());
    return response()->json(['message' => 'Successfully updated'], Response::HTTP_OK);
  }

  public function artisan($params)
  {
    switch ($params) {
      case 'cache':
        \Artisan::call('cache:clear');
        \Artisan::call('view:clear');
        \Artisan::call('logs:clear');
        \Artisan::call('config:cache');
        \Artisan::call('route:cache');
        return response()->json(['message' => 'All Cache Cleared Successfully'], Response::HTTP_OK);
        break;

      default:
        return response()->json(['message' => 'Pass a Valid Argument'], Response::HTTP_NON_AUTHORITATIVE_INFORMATION);
        break;
    }
  }

  protected function is_connected()
  {
    if (@fsockopen('www.google.com', 80)) {
      return true;
    } else {
      return false;
    }
  }
  public function sync()
  {

    if ($this->is_connected()) {
      $status = Response::HTTP_OK;
      $filename = 'samacar.db';
      $server = config('dbsync.server');

      $url = "http://$server/sync/";
      $content = file_get_contents($url . 'last_updated.php');
      $json = json_decode($content, true);
      $last_change = (int) Sync::orderBy('id', 'desc')->first()->changed_at;
      // dd($json['updated_at'] > filemtime(database_path('samacar.db')) );

      if ($json['changed_at'] === $last_change) {
        $res = "Database is Already Up to Date";
      } else if ($json['changed_at'] > $last_change) {
        $copied = copy($url . $filename, database_path($filename));
        $res = $copied ? 'Database Successfully Downloaded!' : 'Problem with Copying New File';
      } else {
        $connection = ssh2_connect($server, '22');
        if (ssh2_auth_password($connection, config('dbsync.user'), config('dbsync.password'))) {
          $resSFTP = ssh2_sftp($connection);
          $filepath = config('dbsync.path');
          $resFile = fopen("ssh2.sftp://{$resSFTP}/$filepath/$filename", 'w');
          $srcFile = fopen(database_path($filename), 'r+');
          $stcopy = stream_copy_to_stream($srcFile, $resFile);

          fclose($resFile);
          fclose($srcFile);

          $res = $stcopy ? 'Database Uploaded to Server!' : 'Problem with uploading';
        } else {
          $res = 'Problem with SFTP! Upload Manually';
          $status = Response::HTTP_INTERNAL_SERVER_ERROR;
        }
      }
    } else {
      $res = 'Connection Failed! Try Manually...';
      $status = 500;
    }
    return response()->json(['message' => $res], $status);
  }

  public function welcome(Setting $setting)
  {
    return view('welcome', compact('setting'));
  }

  public function lang()
  {
    if (!app()->isLocale('bn')) {
      app()->setlocale('bn');
      session(['locale' => 'bn']);
    } else {
      app()->setlocale('en');
      session(['locale' => 'en']);
    }
    return redirect()->back()->with('success', \Lang::get('message.language_change'));
  }
}
