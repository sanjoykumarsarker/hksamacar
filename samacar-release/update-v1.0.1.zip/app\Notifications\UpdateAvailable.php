<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Notification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;

class UpdateAvailable extends Notification
{
    use Queueable;

    public function __construct()
    { }


    public function via($notifiable)
    {
        return ['mail', 'database'];
    }


    public function toMail($notifiable)
    {
        return (new MailMessage)
            ->line('A New Update is Available')
            ->line('Please Download and Install the New Update')
            ->action('Go to App', 'http://localhost:8000/settings')
            ->line('Hare Krishna Hare Krishna Krishna Krishna Hare Hare')
            ->line('Hare Rama Hare Rama Rama Rama Hare Hare');
    }



    public function toDatabase($notifiable)
    {
        return [
            "message" => 'A New Update is Available',
            "link" => "/settings"
        ];
    }

    public function toArray($notifiable)
    {
        return [
            //
        ];
    }
}
