<?php

return [
    'title' => 'HKSAMACAR',
    'dashboard' => 'Dashboard',
    'customer' => 'Customer',
    'product' => 'Product',
    'invoice' => 'Invoice',
    'reports' => 'Reports',
    'settings' => 'Settings',
    'accounts' => 'Accounts',
    'expenses' => 'Expenses',
    'income' => 'Income',
    'balance_sheet' => 'Balance Sheet',
    'profile' => 'Profile',
    'logout' => 'Logout',
    'users' => 'Users',
    'newspaper' => 'Newspaper',
    'management' => "Management",
    'users' => 'Users',
    'samacar' => 'samacar',
];
