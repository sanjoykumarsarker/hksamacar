<template>
  <div>
    <div class="card shadow-sm">
      <div class="card-header bg-success">
        <h4 class="text-light">Settings</h4>
      </div>
      <div class="card-body">
        <div class="row">
          <div class="col-lg-3 mb-3">
            <div class="card shadow-sm">
              <div class="card-body d-flex flex-column align-items-start">
                <loading-button @click.prevent="showConfirm" icon="fa-trash">Clear Cache</loading-button>

                <loading-button
                  icon="fa-sync"
                  color="info"
                  @click.prevent="checkForUpdate"
                >Check Update</loading-button>

                <loading-button
                  v-if="readyToInstall"
                  icon="fa-file-export"
                  color="dark"
                  @click.prevent="checkForUpdate"
                >Ready to Install</loading-button>
              </div>
            </div>
          </div>
          <div class="col-lg-9">
            <div class="form-group shadow-sm p-3">
              <div class="alert alert-danger fade show" role="alert" v-if="create_error">
                {{create_error}}
                <button
                  type="button"
                  class="close"
                  aria-label="Close"
                  @click="create_error=''"
                >
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <label>Create New Setting</label>
              <div class="input-group">
                <input type="text" class="form-control" placeholder="Key" v-model="setting.key" />
                <input type="text" class="form-control" placeholder="Value" v-model="setting.value" />
                <div class="input-group-prepend">
                  <button class="btn btn-primary" @click="createSetting">Add New</button>
                </div>
              </div>
            </div>
            <div class="form-group row" v-for="(f, d, i) in form" :key="i">
              <label class="col-md-5 col-form-label text-uppercase">{{d | removeUnderScore}}</label>
              <div class="col-md-7">
                <template v-if="f === true || f=== false">
                  <div class="pt-1">
                    <b-form-checkbox required switch size="lg" v-model="form[d]"></b-form-checkbox>
                  </div>
                </template>
                <template v-else-if="Array.isArray(f)">
                  <div class="pt-1">
                    <tag-fields v-model="form[d]"></tag-fields>
                  </div>
                </template>
                <template v-else>
                  <input
                    :type="`${isNaN(f) ? 'text' : 'number'}`"
                    class="form-control"
                    v-model="form[d]"
                  />
                </template>
              </div>
            </div>
            <div class="form-group d-flex justify-content-end">
              <button class="btn btn-primary" @click="update">Update</button>
            </div>
          </div>
        </div>
      </div>
    </div>
    <confirm-modal></confirm-modal>
  </div>
</template>

<script>
import loadingBtn from "./LoadingButton.vue";
import { TagFields } from "vue-tag-fields";
export default {
  name: "settings",
  filters: {
    removeUnderScore(value) {
      if (!value) return "";
      return value.split("_").join(" ");
    }
  },
  data() {
    return {
      loading: false,
      editExpense: false,
      newExpense: "",
      form: {},
      expenseType: [],
      setting: {},
      create_error: "",
      readyToInstall: false
    };
  },
  mounted() {
    this.getSetting();
  },
  components: {
    "loading-button": loadingBtn,
    TagFields
  },
  methods: {
    async createSetting() {
      try {
        const { data } = await axios.post("/settings", this.setting);
        this.form = data;
        this.setting = {};
        this.$toasted
          .success("New Settings Added Successfully", {
            icon: "thumbs-up"
          })
          .goAway(3000);
      } catch (error) {
        this.create_error = error.response.data.message;
      }
    },
    async getSetting() {
      const { data } = await axios.get("/settings");
      this.form = data;
    },
    async update() {
      await axios.post("/settings/update", this.form);

      this.$toasted
        .success("Updated Successfully", {
          icon: "thumbs-up"
        })
        .goAway(3000);
    },
    cacheClear: function() {
      axios.post("/settings/cache").then(res => {
        this.$toasted
          .success(`${res.data.message}`, {
            icon: "thumbs-up"
          })
          .goAway(3000);
      });
    },
    showConfirm: function(e) {
      this.$condal.show({
        onConfirm: () => {
          return this.cacheClear();
        }
      });
    },
    async downloadUpdate() {
      const { data } = await axios.get("/settings/download-update");
      this.$bvModal.msgBoxOk(data, {
        title: "Update Message",
        size: "sm",
        buttonSize: "sm",
        okVariant: "success",
        headerClass: "p-2 border-bottom-0",
        footerClass: "p-2 border-top-0",
        centered: true
      });
    },
    async checkForUpdate() {
      const { data } = await axios.get("/settings/check-update");
      if (data.ready) {
        const confirm = await this.$bvModal.msgBoxConfirm(data.message, {
          size: "sm",
          buttonSize: "sm",
          okTitle: "Download",
          centered: true,
          title: "Are you ready to download?",
          headerClass: "border-bottom-0 bg-dark p-2 text-light",
          footerClass: "p-2 border-top-0"
        });
        if (!confirm) return false;
        this.downloadUpdate();
      } else {
        this.$toasted
          .show(data.message, {
            type: data.status,
            icon: "file-download"
          })
          .goAway(3500);
      }
    }
  }
};
</script>