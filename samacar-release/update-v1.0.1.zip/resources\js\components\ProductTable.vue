<template>
  <div class="card shadow mb-4">
    <div class="card-header py-3 d-flex flex-sm-row flex-column justify-content-between">
      <h3 class="font-weight-bold text-primary ml-2">
        Products
        <span class="badge badge-danger">{{total}}</span>
      </h3>
      <form class="form-inline">
        <div class="input-group">
          <input
            type="text"
            class="form-control bg-light border-1 small"
            placeholder="Search for..."
            aria-label="Search"
            aria-describedby="basic-addon2"
            v-model="searchfor"
            @keypress="searchProduct()"
          />
          <div class="input-group-append">
            <button
              class="btn btn-primary"
              type="button"
              data-toggle="tooltip"
              data-placement="bottom"
              title="Just Type to Search"
            >
              <i class="fas fa-search fa-sm"></i>
            </button>
          </div>
        </div>
        <button
          class="btn btn-primary ml-2"
          type="button"
          @click.prevent="openModal('Add Product')"
          data-toggle="tooltip"
          data-placement="top"
          title="Add New Product"
        >
          <i class="fas fa-book-medical"></i>
        </button>
      </form>
    </div>
    <div class="card-body">
      <div class="table-responsive" v-if="!error">
        <table class="table table-bordered" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>Pic</th>
              <th>Title</th>
              <th>Price</th>
              <th>Stock</th>
              <th width="15%"></th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="product in products" :key="product.id">
              <td>
                <img
                  :src="'img/books/'+ product.image"
                  alt="Product"
                  class="img-responsive"
                  width="30"
                />
              </td>
              <td>{{product.name}}</td>
              <td>{{product.price}}</td>
              <td>{{product.stock.toLocaleString('us')}}</td>
              <td>
                <div class="d-flex justify-content-around">
                  <button
                    class="btn btn-sm btn-info"
                    @click.prevent="openModal('Add Inventory', product.id)"
                    title="Add Inventory"
                    data-toggle="tooltip"
                    data-placement="top"
                  >
                    <i class="fas fa-plus"></i>
                  </button>
                  <button
                    class="btn btn-sm btn-success"
                    @click.prevent="openModal('Edit Product', product.id)"
                    title="Edit Product"
                    data-toggle="tooltip"
                    data-placement="top"
                  >
                    <i class="fas fa-pencil-alt"></i>
                  </button>
                  <a
                    class="btn btn-sm btn-dark"
                    :href="'/product/' + product.id "
                    title="View Details"
                    data-toggle="tooltip"
                    data-placement="top"
                  >
                    <i class="fas fa-eye"></i>
                  </a>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
        <pagination-link
          :currentPage="currentPage"
          :lastPage="lastPage"
          :linksToShow="10"
          @previous="prevButton"
          @next="nextButton"
          @change="changePage"
        ></pagination-link>
      </div>
      <div v-else class="text-center">
        <h1>Oh No 😢</h1>
        <p class="text-center">
          <img src="img/wifi.svg" alt="Connection Error" width="100" />
        </p>
        <h4>There may be network error.</h4>
      </div>
    </div>
    <modal-dialog v-if="showModal" :closeModal="closeModal" :title="modalFor">
      <product-form @newProduct="newProduct" v-if="modalFor==='Add Product'"></product-form>
      <product-form
        @newProduct="newProduct"
        v-else-if="modalFor==='Edit Product'"
        :preselected.sync="selected"
      ></product-form>
      <inventory-form :selectedProduct="selected" @newInventory="newInventory" v-else></inventory-form>
    </modal-dialog>
  </div>
</template>
<script>
import PaginationLinkVue from "./PaginationLink.vue";
import debounce from "./mixins/debounce";
export default {
  name: "product-table",
  data() {
    return {
      showModal: false,
      modalFor: "Add Product",
      total: "",
      searchfor: "",
      error: false,
      products: [],
      currentPage: "",
      lastPage: "",
      loading: false,
      selected: {}
    };
  },
  methods: {
    async init() {
      const { data } = await axios.get("/api/products");
      this.setData(data);
    },
    load: function(page) {
      this.loading = true;
      axios
        .get(`/api/products?page=${page}`)
        .then(({ data }) => {
          this.setData(data);
        })
        .catch(err => {
          this.error = true;
        });
    },
    openModal: function(val, id = 0) {
      this.showModal = true;
      this.modalFor = val;
      this.selected = this.products.find(p => p.id === id);
      // document.body.style.overflowY = "hidden";
    },
    closeModal: function() {
      this.showModal = false;
      // document.body.style.overflowY = "";
    },
    nextButton: function() {
      this.currentPage += 1;
      this.load(this.currentPage);
    },
    prevButton: function() {
      this.currentPage -= 1;
      this.load(this.currentPage);
    },
    changePage: function(page) {
      this.currentPage = page;
      this.load(page);
    },
    searchProduct: debounce(async function(val = null) {
      this.loading = true;
      const { data } = await axios.post("/api/products", {
        search: val || this.searchfor
      });
      this.setData(data);
      this.loading = false;
    }, 500),
    setData: function(data) {
      this.products = [...data.products.data];
      this.currentPage = data.products.current_page;
      this.lastPage = data.products.last_page;
      this.total = data.products.total;
    },
    newProduct: function(product) {
      this.init();
      if (product) {
        setTimeout(() => {
          this.openModal("Add Inventory", product.id);
        }, 2000);
      } else {
        this.closeModal();
      }
    },
    newInventory: function(stock) {
      // this.init();
      this.products = this.products.map(p => {
        if (p.id === stock.product_id) {
          return {
            ...p,
            stock: stock.product.stock
          };
        }
        return p;
      });
      setTimeout(() => this.closeModal(), 1000);
    }
  },
  created() {
    this.init();
  },
  components: {
    "pagination-link": PaginationLinkVue
  }
};
</script>