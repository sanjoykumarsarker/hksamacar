<?php

namespace App\Http\Controllers;

use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Hash;
use Symfony\Component\HttpFoundation\Response;

class UserController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $users = User::whereNotIn('id', [\Auth::id()])->paginate(10);
        return view('user.index', compact('users'));
    }


    public function create()
    {
        //
    }


    public function store(Request $request)
    {
        // New User will be created using default registration
    }

    public function activation(User $user)
    {
        if (!$user->is_active) {
            $user->update(['banned_until' => null]);
            $user->save();
            return redirect()->back()->with("success", $user->name . " Successfully Activated.");
        }
    }

    public function deactivation(Request $request)
    {
        $request->validate([
            'user_id' => 'required',
            'date' => 'required|date|after:1 days'
        ]);
        $user = User::find($request->get('user_id'));
        $user->banned_until = $request->get('date');
        $user->save();
        $banned_days = now()->diffInDays($user->banned_until);
        return redirect()->back()->with("success", $user->name . " Deactivated for $banned_days Days");
    }

    public function password_update(Request $request, User $user)
    {
        $request->validate([
            // 'password'          =>  'required|min:8|regex:/^(?=\S*[a-z])(?=\S*[!@#$&*])(?=\S*[A-Z])(?=\S*[\d])\S*$/',
            'password'          =>  'required|min:8|bail',
            'confirmpassword'   =>  'required|same:password'
        ]);
        if ((Hash::check($request->get('password'), $user->password))) {
            //Current password and new password are same
            return redirect()->back()->with("error", "New Password is Same as Current Password.");
        }
        if ($user->id == \Auth::id()) {
            $user->password = bcrypt($request->get('password'));
            $user->save();
            return redirect()->back()->with("success", "Password Successfully Changed.");
        }
        return redirect()->back()->with("error", "Sorry! You can not Change Password.");
    }


    public function show(User $user)
    {
        $activities = $user->activities()->orderBy('created_at', 'desc')->paginate(10);
        return view('user.show', compact('user', 'activities'));
    }


    public function edit(User $user)
    {
        //
    }

    public function update(Request $request, User $user)
    {
        $user->update($request->validate([
            'name' => 'required|string|min:6',
            'email' => 'required|email',
            'role' => 'required|string',
        ]));
        return redirect()->back()->with("success", "Data Successfully Updated.");
    }


    public function destroy(User $user)
    {
        $this->authorize('isSuperAdmin');
        $msg = ['message' => "You can not delete your account."];
        if ($user->id === \Auth::id()) return response()->json($msg, Response::HTTP_NOT_ACCEPTABLE);
        $user->delete();
        return response()->noContent();
    }
}
