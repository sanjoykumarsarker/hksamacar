/**
 * First we will load all of this project's JavaScript dependencies which
 * includes Vue and other libraries. It is a great starting point when
 * building robust, powerful web applications using Vue and Laravel.
 */

require("./bootstrap");
import bn from "./lib/number";
window.bn = bn;

window.Vue = require("vue");
import store from "./store";
import router from "./router";
import Snowf from "vue-snowf";
import Toasted from "vue-toasted";
import ConfirmModal from "./lib/confirm/index";
import NProgress from "nprogress";
import Vuebar from "vuebar";
Vue.use(Vuebar);
Vue.use(Toasted, { iconPack: "fontawesome" });
Vue.use(ConfirmModal);
import {
    ModalPlugin,
    OverlayPlugin,
    ProgressPlugin,
    FormCheckboxPlugin,
    TabsPlugin,
    VBPopoverPlugin,
    FormTagsPlugin
} from "bootstrap-vue";
Vue.use(ModalPlugin);
Vue.use(OverlayPlugin);
Vue.use(ProgressPlugin);
Vue.use(FormCheckboxPlugin);
Vue.use(TabsPlugin);
Vue.use(VBPopoverPlugin);
Vue.use(FormTagsPlugin);


/**
 * The following block of code may be used to automatically register your
 * Vue components. It will recursively scan this directory for the Vue
 * components and automatically register them with their "basename".
 *
 * Eg. ./components/ExampleComponent.vue -> <example-component></example-component>
 */

// const files = require.context('./', true, /\.vue$/i)
// files.keys().map(key => Vue.component(key.split('/').pop().split('.')[0], files(key).default))

Vue.component("let-it-snow", Snowf);

Vue.component(
    "table-component",
    require("./components/TableComponent.vue").default
);
Vue.component(
    "inventory-form",
    require("./components/InventoryForm.vue").default
);
Vue.component(
    "product-table",
    require("./components/ProductTable.vue").default
);
Vue.component(
    "customer-table",
    require("./components/CustomerTable.vue").default
);
Vue.component("paginated-table", require("./components/Table.vue").default);
// Vue.component(
//     "customer-form",
//     require("./components/CustomerForm.vue").default
// );
Vue.component("payment-form", require("./components/PaymentForm.vue").default);
Vue.component("product-form", require("./components/ProductForm.vue").default);
Vue.component("expense-form", require("./components/ExpenseForm.vue").default);
Vue.component(
    "manage-expense-type",
    require("./components/expense/managetypes.vue").default
);
Vue.component("modal-dialog", require("./components/Modal.vue").default);
Vue.component("settings", require("./components/Settings.vue").default);
Vue.component("invoice", require("./components/InvoiceCreate.vue").default);
Vue.component(
    "search-select",
    require("./components/SearchSelect.vue").default
);
Vue.component("get-month", require("./components/GetMonth.vue").default);
Vue.component(
    "vrange-selector",
    require("./lib/vuelender/components/vl-range-selector.vue").default
);
Vue.component("date-select", require("./components/DateRange.vue").default);
Vue.component(
    "subscriber-edit",
    require("./components/SubscriberEdit.vue").default
);
Vue.component(
    "subscriber-renew-form",
    require("./components/SubscriberRenewForm.vue").default
);
Vue.component(
    "product-return",
    require("./components/ProductReturn.vue").default
);
Vue.component(
    "subscription-toggle",
    require("./components/SubscriptionToggle.vue").default
);
Vue.component(
    "newspaper-update",
    require("./components/NewspaperUpdate.vue").default
);
Vue.component(
    "send-single-paper",
    require("./components/SendSinglePaper.vue").default
);
Vue.component("api-login", require("./components/ApiLogin.vue").default);
Vue.component(
    "header-search",
    require("./components/HeaderSearch/index.vue").default
);
const CancelToken = axios.CancelToken;

const app = new Vue({
    router,
    store,
    el: "#app",
    data() {
        return {
            showOverlay: false,
            requestCancel: ""
        };
    },
    methods: {
        async dbSync() {
            // document.body.style.overflow = "hidden!important";
            document.body.style.height = "100vh";
            this.showOverlay = true;
            try {
                const { data } = await axios.post(
                    "/settings/sync",
                    {},
                    {
                        cancelToken: new CancelToken(
                            c => (this.requestCancel = c)
                        )
                    }
                );
                this.showOverlay = false;
                this.$toasted
                    .success(data.message, {
                        icon: "database"
                    })
                    .goAway(3500);
            } catch (error) {
                this.showOverlay = false;
            }
        },
        cancelDbSync() {
            this.requestCancel("Operation canceled by the user.");
        }
    },
    mounted() {
        $('[data-toggle="tooltip"]').tooltip();
    }
});

// Add a request interceptor
axios.interceptors.request.use(
    function(config) {
        NProgress.start();
        // console.log(config);
        return config;
    },
    function(error) {
        // Do something with request error
        // console.error(error)
        return Promise.reject(error);
    }
);

// Add a response interceptor
axios.interceptors.response.use(
    function(response) {
        NProgress.done();
        return response;
    },
    function(error) {
        // Do something with response error
        NProgress.done();
        app.$toasted
            .show(`Error: ${error.message || error.toString()}`, {
                type: "error",
                icon: "exclamation-triangle"
            })
            .goAway(3500);
        return Promise.reject(error);
    }
);

(function($) {
    "use strict"; // Start of use strict

    // Toggle the side navigation
    $("#sidebarToggle, #sidebarToggleTop").on("click", function(e) {
        $("body").toggleClass("sidebar-toggled");
        $(".sidebar").toggleClass("toggled");
        if ($(".sidebar").hasClass("toggled")) {
            $(".sidebar .collapse").collapse("hide");
        }
    });

    // Close any open menu accordions when window is resized below 768px
    $(window).resize(function() {
        if ($(window).width() < 768) {
            $(".sidebar .collapse").collapse("hide");
        }
    });

    // Prevent the content wrapper from scrolling when the fixed side navigation hovered over
    $("body.fixed-nav .sidebar").on("mousewheel DOMMouseScroll wheel", function(
        e
    ) {
        if ($(window).width() > 768) {
            var e0 = e.originalEvent,
                delta = e0.wheelDelta || -e0.detail;
            this.scrollTop += (delta < 0 ? 1 : -1) * 30;
            e.preventDefault();
        }
    });

    // Scroll to top button appear
    $(document).on("scroll", function() {
        var scrollDistance = $(this).scrollTop();
        if (scrollDistance > 100) {
            $(".scroll-to-top").fadeIn();
        } else {
            $(".scroll-to-top").fadeOut();
        }
    });

    // Smooth scrolling using jQuery easing
    $(document).on("click", "a.scroll-to-top", function(e) {
        var $anchor = $(this);
        $("html, body")
            .stop()
            .animate(
                {
                    scrollTop: $($anchor.attr("href")).offset().top
                },
                1000,
                "easeInOutExpo"
            );
        e.preventDefault();
    });

    function openFullscreen(elem) {
        if (elem.requestFullscreen) {
            elem.requestFullscreen();
        } else if (elem.mozRequestFullScreen) {
            elem.mozRequestFullScreen();
        } else if (elem.webkitRequestFullscreen) {
            elem.webkitRequestFullscreen();
        } else if (elem.msRequestFullscreen) {
            elem.msRequestFullscreen();
        }
    }

    $(".fullscreen").on("click", e => {
        e.preventDefault();
        openFullscreen(document.body);
    });

    $('[data-toggle="tooltip"]').tooltip();
    $('[data-toggle="popover"]').popover();
})(jQuery);

// if ('serviceWorker' in navigator) {
//   window.addEventListener('load', () => {
//     navigator.serviceWorker.register('/sw.js').then(registration => {
//       console.log('SW registered: ', registration);
//       // registration.pushManager.subscribe({ userVisibleOnly: true });
//     }).catch(err => {
//       console.log(err)
//     });
//   });
// }

// if ("serviceWorker" in navigator) {
//     window.addEventListener("load", () => {
//         navigator.serviceWorker.register("/service-worker.js");
//     });
// }
