<?php

// use App\Jobs\SyncDatabase;

Route::get('/', 'SettingsController@welcome')->name('welcome');
Route::get('/lang', 'SettingsController@lang')->name('lang');

Auth::routes();
Route::impersonate();

Route::get('/home', 'HomeController@index')->name('home');

Route::prefix('settings')->group(function () {
    Route::post('/sync', 'SettingsController@sync')->name('settings.sync');
    Route::get('/', 'SettingsController@index')->name('settings')->middleware('impersonate.protect');
    Route::post('editExpenseType', 'SettingsController@editExpenseType');
    Route::post('/', 'SettingsController@store');
    Route::get('/check-update', 'SettingsController@checkForUpdate');
    Route::get('/download-update', 'SettingsController@downloadUpdate');
    Route::post('update', 'SettingsController@update');
    Route::post('{params}', 'SettingsController@artisan')->name('settings.run');
});

Route::resource('/user', 'UserController')->except(['create', 'edit']);
Route::prefix('user')->group(function () {
    Route::post('pwd-update/{user}', 'UserController@password_update')->name('password.update');
    Route::post('deactivate', 'UserController@deactivation')->name('user.deactivation');
    Route::post('activate/{user}', 'UserController@activation')->name('user.activation');
});

Route::resource('/customer', 'CustomerController')->except('api');
Route::resource('/expense-types', 'ExpenseTypeController')->except('updateOrder');
Route::post("/expense-types/order", 'ExpenseTypeController@updateOrder');
Route::resource('/account', 'AccountController');
Route::resource('/expense', 'ExpenseController');
Route::resource('/product', 'ProductController')->except(['api', 'addInventory']);
Route::resource('/invoice', 'InvoiceController');
Route::post('/product/inventory/{product}', 'ProductController@addInventory')->name('addInventory');

// Report
Route::prefix('report')->name('report.')->group(function () {
    Route::get('/', 'ReportController@index')->name('index');
    Route::get('dues', 'ReportController@dues')->name('dues');
    Route::get('summary', 'ReportController@summary')->name('summary');
    Route::get('expense', 'ReportController@expense')->name('expense');
    Route::get('sales', 'ReportController@sales')->name('sales');
});

Route::prefix('product')->group(function () {
    Route::get('return/{customer}/all', 'ProductReturnController@index')->name('product.return');
    Route::get('return/{return}', 'ProductReturnController@show')->name('productreturn.show');
    Route::post('return/{customer}', 'ProductReturnController@store');
});

Route::prefix('pdf')->name('pdf.')->group(function () {
    Route::get('sales', 'PdfController@sales')->name('sales');
    Route::get('expenses', 'PdfController@expenses')->name('expenses');
    Route::get('subscribe/{subscribe}', 'PdfController@subscribe')->name('subscribe');
    Route::get('invoice/{invoice}', 'PdfController@invoice')->name('invoice');
});

Route::prefix('subscription')->group(function () {
    Route::post('customer/{customer}', 'SubscriptionController@subscribe')->name('subscribe');
    Route::post('status/{subscription}', 'SubscriptionController@status')->name('subscribe.status');
});

Route::prefix('agent')->name('agent.')->group(function () {
    Route::post('customer/{customer}', 'AgentController@update')->name('update');
    Route::post('status/{agent}', 'AgentController@status')->name('status');
});

Route::prefix('newspaper')->name('newspaper.')->group(function () {
    Route::get('index', 'SendNewspaperController@index')->name('index');
    Route::post('send', 'SendNewspaperController@send')->name('send');
    Route::post('print', 'SendNewspaperController@print')->name('print');
    Route::get('search', 'SendNewspaperController@search')->name('search');
    Route::post('update/{newspaper}', 'SendNewspaperController@update')->name('update');
});

// Samacar Routes
Route::prefix('samacar')->name('samacar.')->group(function () {
    Route::get('/', function () {
        return view('samacar.index');
    })->name('subscribers');

    Route::get('member/{id}', function ($id) {
        return view('samacar.edit', compact('id'));
    })->name('subscribers.edit');
});

// use Tymon\JWTAuth\Facades\JWTAuth;
// use Illuminate\Http\Request;

// Route::group(['middleware' => 'api'], function ($router) {
//     $router->get('/ping', function (Request $request) {
//         return response()->json(["data" => true, "user" => $request->user(), "status" => 200], 200);
//     });
// });
// use Tymon\JWTAuth\Exceptions\JWTException;


Route::get('/apilogin', function () {
    return view('apilogin');
})->name('apilogin');

// Route::post('/api_token', function (Request $request) {
//     $input = $request->only('email', 'password');
//     $jwt_token = null;
//     if (!$jwt_token = JWTAuth::attempt($input)) {
//         return response()->json([
//             'success' => false,
//             'message' => 'Invalid Email or Password',
//         ], Response::HTTP_UNAUTHORIZED);
//     }
//     return response()->json([
//         'success' => true,
//         'token' => $jwt_token,
//     ]);
// });

Route::get('/test-ftp', function () {
    // SyncDatabase::dispatch('upload')->onQueue('sync');
    return response()->json(['msg' => 'process queued'], 200);
});

// Route::get('/test', function (Setting $setting) {
//     return response()->json(['sd' => $setting->all()], 200);
// });
