<?php

// Route::middleware('auth:api')->get('/user', function (Request $request) {
//     return $request->user();
// });
// Route::middleware('auth:api')->get('/user', function (Request $request) {
//     return $request->user();
// });
// Route::middleware('auth:api')->get('/user', function (Request $request) {
//     return $request->user();
// });

Route::any('customers', 'CustomerController@api')->name('customers');
Route::get('customers/all', 'CustomerController@all')->name('all-customers');
Route::post('customers/{customer}', 'CustomerController@status')->name('customers-status');
// Route::any('products', 'ProductController@api')->name('products.api');
// Route::get('productsales', 'ProductController@sales');